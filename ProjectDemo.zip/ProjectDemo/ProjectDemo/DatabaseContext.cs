﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Entity;
using System.Runtime.Remoting.Contexts;
using System.Windows.Controls;
using ProjectDemo.Models;

namespace ProjectDemo
{

    public class DatabaseContext : DbContext
    {
        public DatabaseContext() : base("name=hotel_demoEntities4")
        {
            this.Configuration.LazyLoadingEnabled = true;
            this.Configuration.ProxyCreationEnabled = true;
        }

        public DbSet<Roles> Roles { get; set; }
        public DbSet<Users> Users { get; set; }
        public DbSet<Clients> Clients { get; set; }
        public DbSet<Rooms> Rooms { get; set; }
        public DbSet<Cards> Cards { get; set; }
        public DbSet<Orders> Orders { get; set; }
        public DbSet<RoomCleaning> RoomCleanings { get; set; }
        public DbSet<HotelServices> HotelServices { get; set; }
        public DbSet<OrderedServices> OrderedServices { get; set; }
        public DbSet<Payments> Payments { get; set; }


        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            // Настройка отношения User-Role (один ко многим)
            modelBuilder.Entity<Users>()
                .HasRequired(u => u.Roles)
                .WithMany()
                .HasForeignKey(u => u.RoleID)
                .WillCascadeOnDelete(false);

            // Настройка отношения Order-Client (один ко многим)
            modelBuilder.Entity<Orders>()
                .HasRequired(o => o.Clients)
                .WithMany()
                .HasForeignKey(o => o.ClientID)
                .WillCascadeOnDelete(false);

            // Настройка отношения Order-Room (один ко многим)
            modelBuilder.Entity<Orders>()
                .HasRequired(o => o.Rooms)
                .WithMany()
                .HasForeignKey(o => o.RoomID)
                .WillCascadeOnDelete(false);

            // Настройка отношения Order-User (один ко многим)
            modelBuilder.Entity<Orders>()
                .HasRequired(o => o.Users)
                .WithMany()
                .HasForeignKey(o => o.UserID)
                .WillCascadeOnDelete(false);

            // Настройка отношения Order-Card (один к одному)
            modelBuilder.Entity<Orders>()
                .HasRequired(o => o.Cards)
                .WithMany()
                .HasForeignKey(o => o.CardID)
                .WillCascadeOnDelete(false);

            // Уникальный индекс для номера комнаты и этажа
            modelBuilder.Entity<Rooms>()
                .HasIndex(r => new { r.Floor, r.RoomNumber })
                .IsUnique();

            // Уникальный индекс для паспортных данных клиента
            modelBuilder.Entity<Clients>()
                .HasIndex(c => c.Passport)
                .IsUnique();

            base.OnModelCreating(modelBuilder);
        }
    }
}

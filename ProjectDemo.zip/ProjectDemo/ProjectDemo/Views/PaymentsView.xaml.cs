﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.Entity;

namespace ProjectDemo.Views
{
    /// <summary>
    /// Логика взаимодействия для PaymentsView.xaml
    /// </summary>
    public partial class PaymentsView : Page
    {
        public PaymentsView()
        {
            InitializeComponent();
            LoadPayments();
        }

        private void LoadPayments()
        {
            using (var context = new DatabaseContext())
            {
                PaymentsDataGrid.ItemsSource = context.Payments
                    .Include(p => p.Orders)
                    .ToList();
            }
        }

        private void AddPayment_Click(object sender, RoutedEventArgs e)
        {
            var window = new AddPaymentWindow();
            if (window.ShowDialog() == true)
            {
                LoadPayments();
            }
        }
    }
}

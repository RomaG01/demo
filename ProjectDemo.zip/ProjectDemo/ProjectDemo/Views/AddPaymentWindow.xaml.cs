﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.Entity;
using ProjectDemo.Models;

namespace ProjectDemo.Views
{
    /// <summary>
    /// Логика взаимодействия для AddPaymentWindow.xaml
    /// </summary>
    public partial class AddPaymentWindow : Window
    {
        public AddPaymentWindow()
        {
            InitializeComponent();
            LoadOrders();
        }

        private void LoadOrders()
        {
            using (var context = new DatabaseContext())
            {
                OrderComboBox.ItemsSource = context.Orders.ToList();
            }
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if (OrderComboBox.SelectedItem == null ||
                !decimal.TryParse(AmountTextBox.Text, out decimal amount) ||
                amount <= 0 ||
                PaymentMethodComboBox.SelectedItem == null)
            {
                MessageBox.Show("Заполните все поля корректно");
                return;
            }

            var payment = new Payments
            {
                OrderID = ((Orders)OrderComboBox.SelectedItem).OrderID,
                Amount = amount,
                PaymentDate = DateTime.Now,
                PaymentMethod = ((ComboBoxItem)PaymentMethodComboBox.SelectedItem).Content.ToString()
            };

            using (var context = new DatabaseContext())
            {
                context.Payments.Add(payment);
                context.SaveChanges();
            }

            DialogResult = true;
            Close();
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}

﻿using ProjectDemo.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ProjectDemo.Views
{
    /// <summary>
    /// Логика взаимодействия для OrdersView.xaml
    /// </summary>
    public partial class OrdersView : Page
    {
        public OrdersView()
        {
            InitializeComponent();
            LoadOrders();
        }

        private void LoadOrders()
        {
            using (var context = new DatabaseContext())
            {
                OrdersDataGrid.ItemsSource = context.Orders
                    .Include(o => o.Clients)
                    .Include(o => o.Rooms)
                    .ToList();
            }
        }

        private void AddOrder_Click(object sender, RoutedEventArgs e)
        {
            var window = new AddOrderWindow();
            if (window.ShowDialog() == true)
            {
                LoadOrders();
            }
        }

        private void CheckOut_Click(object sender, RoutedEventArgs e)
        {
            var selectedOrder = OrdersDataGrid.SelectedItem as Orders;
            if (selectedOrder != null)
            {
                using (var context = new DatabaseContext())
                {
                    var order = context.Orders.Find(selectedOrder.OrderID);
                    if (order != null)
                    {
                        // Обновляем статус номера
                        var room = context.Rooms.Find(order.RoomID);
                        room.RoomStatus = "Грязный";

                        // Блокируем карту доступа
                        var card = context.Cards.Find(order.CardID);
                        if (card != null)
                        {
                            card.DestroyDate = DateTime.Now;
                        }

                        context.SaveChanges();
                        LoadOrders();
                    }
                }
            }
            else
            {
                MessageBox.Show("Выберите бронирование для оформления выезда");
            }
        }

        private void AddService_Click(object sender, RoutedEventArgs e)
        {
            var selectedOrder = OrdersDataGrid.SelectedItem as Orders;
            if (selectedOrder != null)
            {
                var window = new AddServiceToOrderWindow(selectedOrder.OrderID);
                if (window.ShowDialog() == true)
                {
                    LoadOrderServices(selectedOrder.OrderID);
                }
            }
            else
            {
                MessageBox.Show("Выберите бронирование для добавления услуги");
            }
        }

        private void OrdersDataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var selectedOrder = OrdersDataGrid.SelectedItem as Orders;
            if (selectedOrder != null)
            {
                LoadOrderServices(selectedOrder.OrderID);
            }
        }

        private void LoadOrderServices(int orderId)
        {
            using (var context = new DatabaseContext())
            {
                OrderServicesDataGrid.ItemsSource = context.OrderedServices
                    .Where(os => os.OrderID == orderId)
                    .Include(os => os.HotelServices)
                    .ToList();
            }
        }
    }
}

﻿using ProjectDemo.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ProjectDemo.Views
{
    /// <summary>
    /// Логика взаимодействия для AddCleaningWindow.xaml
    /// </summary>
    public partial class AddCleaningWindow : Window
    {
        public AddCleaningWindow()
        {
            InitializeComponent();
            LoadRooms();
        }

        private void LoadRooms()
        {
            using (var context = new DatabaseContext())
            {
                RoomComboBox.ItemsSource = context.Rooms.ToList();
            }
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if (RoomComboBox.SelectedItem == null || string.IsNullOrWhiteSpace(CleanerTextBox.Text))
            {
                MessageBox.Show("Заполните все поля");
                return;
            }

            var cleaning = new RoomCleaning
            {
                RoomID = ((Rooms)RoomComboBox.SelectedItem).RoomID,
                CleaningDate = DateTime.Now,
                CleanerName = CleanerTextBox.Text,
                Status = "Назначена"
            };

            using (var context = new DatabaseContext())
            {
                context.RoomCleanings.Add(cleaning);
                context.SaveChanges();

                // Обновляем статус номера
                var room = context.Rooms.Find(cleaning.RoomID);
                room.RoomStatus = "Назначен к уборке";
                context.SaveChanges();
            }

            DialogResult = true;
            Close();
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ProjectDemo.Views
{
    /// <summary>
    /// Логика взаимодействия для UserDashboard.xaml
    /// </summary>
    public partial class UserDashboard : Window
    {
        public UserDashboard()
        {
            InitializeComponent();
            MainFrame.Content = new ClientsView();
        }

        private void ClientsMenuItem_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Content = new ClientsView();
        }

        private void RoomsMenuItem_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Content = new RoomsView();
        }

        private void OrdersMenuItem_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Content = new OrdersView();
        }

        private void LogoutMenuItem_Click(object sender, RoutedEventArgs e)
        {
            var authWindow = new AuthWindow();
            authWindow.Show();
            this.Close();
        }
    }
}
